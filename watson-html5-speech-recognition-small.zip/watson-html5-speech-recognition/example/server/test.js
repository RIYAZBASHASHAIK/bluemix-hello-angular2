var Speech = require('watson-html5-speech-recognition');
var speech = new Speech.SpeechToText();

console.log(speech);